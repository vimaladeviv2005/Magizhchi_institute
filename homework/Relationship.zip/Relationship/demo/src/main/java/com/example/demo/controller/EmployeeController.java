package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Employee;
import com.example.demo.service.EmployeeService;
@RestController

public class EmployeeController {
    
    @Autowired
    EmployeeService service;

    @PostMapping("/save")
    public Employee saveEmployee(@RequestBody Employee emp) {
        return service.save(emp);
    }

}
