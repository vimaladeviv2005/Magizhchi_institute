package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.Department;
import com.example.demo.repository.DepartmentRepository;
@Service
public class EmployeeService {
    @Autowired
    DepartmentRepository repo;
    public Department save(Department dept) {
       return repo.save(dept);
    }
    
}
