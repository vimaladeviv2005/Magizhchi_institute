package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Department;
import com.example.demo.service.EmployeeService;
@RestController
public class EmployeeController {
        @Autowired
    EmployeeService service;

    @PostMapping("/save")
    public Department saveDepartment(@RequestBody Department dept) {
        return service.save(dept);
    }

}
